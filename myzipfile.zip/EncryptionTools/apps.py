from django.apps import AppConfig


class EncryptionToolsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'EncryptionTools'
